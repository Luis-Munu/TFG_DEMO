import streamlit as st
from st_pages import Page, show_pages, hide_pages
from PIL import Image
import base64

st.set_page_config(page_title="InversApp", page_icon="🏠", layout="wide", initial_sidebar_state="expanded")


show_pages(
    [
        Page("website.py", "Página principal", ":house:"),
        Page("pages/property_finder.py", "Buscador de viviendas", "🏠"),
        Page("pages/zone_finder.py", "Análisis por zonas", "🌍"),
        Page("pages/user_profile.py", "Menú de usuario", "✏️"),
        Page("pages/property_statistics.py","Caracteristicas de la propiedad", "📈"),
        Page("pages/zone_statistics.py","Estadisticas de la zona", "📊")
    ]
)

hide_pages(["Caracteristicas de la propiedad", "Estadisticas de la zona"])

st.markdown("""
  <style>
    .css-13sdm1b.e16nr0p33 {
      margin-top: -75px;
    }
  </style>
""", unsafe_allow_html=True)

st.markdown("""
        <style>
               .block-container {
                    padding-top: 1rem;
                    padding-bottom: 0rem;
                    padding-left: 5rem;
                    padding-right: 5rem;
                }
        </style>
        """, unsafe_allow_html=True)

def get_base64_of_bin_file(png_file):
    with open(png_file, "rb") as f:
        data = f.read()
    return base64.b64encode(data).decode()

def build_markup_for_logo(
    png_file,
    background_position="5% 5%",
    margin_top="10%",
    image_width="120%",
    image_height="",
):
    binary_string = get_base64_of_bin_file(png_file)
    return """
            <style>
                [data-testid="stSidebar"][aria-expanded="true"]{
                      min-width: 200px;
                      max-width: 200px;
                }
                [data-testid="stSidebarNav"] {
                    background-position: -20px 20px;
                    text-align: center;
                    display: block;
                    background-image: url("data:image/png;base64,%s");
                    background-repeat: no-repeat;
                    margin-top: %s;
                    margin-left: auto;
                    margin-right: auto;
                    background-size: %s %s;
                    padding-top: 120px;
                }
                [data-testid="stSidebarNav"]::before {
                    text-align: center;
                    content: "InversAPP";
                    margin-left: -15px;
                    margin-top: 20px;
                    font-size: 30px;
                    position: relative;
                    top: 100px;
                }
            </style>
            """ % (
        binary_string,
        margin_top,
        image_width,
        image_height,
    )


def add_logo(png_file):
    logo_markup = build_markup_for_logo(png_file)
    st.markdown(
        logo_markup,
        unsafe_allow_html=True,
    )

add_logo("images/logon.png")

st.markdown("<h1 style='text-align: center; color: grey;'>¡Bienvenido a InversApp!</h1>", unsafe_allow_html=True)
st.markdown("<h3 style='text-align: center; color: white;'><br><br>InversApp te ofrece las mejores herramientas de análisis y búsqueda de propiedades para invertir.</h1>", unsafe_allow_html=True)

# Background images and logo
image = Image.open('images/logon.png')
st.image(image, width=1400)

property_finder_text = "Buscador de propiedades: Encuentra propiedades en función de tus criterios."
property_statistics_text = "Estadisticas de propiedad: Analiza los datos clave de una propiedad seleccionada."
zone_finder_text = "Estadisticas de zona: Descubre valiosa información de múltiples localizaciones."
user_data_text = "Datos del usuario: Gestiona tus datos, preferencias y propiedades favoritas."

left_col, right_col = st.columns(2)

left_col.markdown(f"- **{property_finder_text}**")
left_col.markdown(f"- **{property_statistics_text}**")

right_col.markdown(f"- **{zone_finder_text}**")
right_col.markdown(f"- **{user_data_text}**")