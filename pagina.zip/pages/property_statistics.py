import streamlit as st
import base64
from st_pages import Page, show_pages, hide_pages
import pandas as pd
from urllib.error import URLError
import plotly.express as px
import altair as alt


st.set_page_config(page_title="Caracteristicas de la propiedad", page_icon="📈", layout="wide", initial_sidebar_state="collapsed")
st.markdown("""
        <style>
               .block-container {
                    padding-top: 1rem;
                    padding-bottom: 0rem;
                    padding-left: 5rem;
                    padding-right: 5rem;
                }
        </style>
        """, unsafe_allow_html=True)

st.markdown("<h1 style='text-align: center; color: grey;'>Caracteristicas de la propiedad</h1>", unsafe_allow_html=True)
st.markdown("<h3 style='text-align: center; color: white;'><br><br>En esta página podrás analizar las Caracteristicas de una propiedad en detalle.</h1>", unsafe_allow_html=True)
show_pages(
    [
        Page("website.py", "Página principal", ":house:"),
        Page("pages/property_finder.py", "Buscador de viviendas", "🏠"),
        Page("pages/zone_finder.py", "Análisis por zonas", "🌍"),
        Page("pages/user_profile.py", "Menú de usuario", "✏️"),
        Page("pages/property_statistics.py","Caracteristicas de la propiedad", "📈"),
        Page("pages/zone_statistics.py","Estadisticas de la zona", "📊")
    ]
)

hide_pages(["Caracteristicas de la propiedad", "Estadisticas de la zona"])

st.markdown("""
  <style>
    .css-13sdm1b.e16nr0p33 {
      margin-top: -75px;
    }
  </style>
""", unsafe_allow_html=True)

st.markdown("""
        <style>
               .block-container {
                    padding-top: 1rem;
                    padding-bottom: 0rem;
                    padding-left: 5rem;
                    padding-right: 5rem;
                }
        </style>
        """, unsafe_allow_html=True)

def get_base64_of_bin_file(png_file):
    with open(png_file, "rb") as f:
        data = f.read()
    return base64.b64encode(data).decode()

def build_markup_for_logo(
    png_file,
    background_position="5% 5%",
    margin_top="10%",
    image_width="120%",
    image_height="",
):
    binary_string = get_base64_of_bin_file(png_file)
    return """
            <style>
                [data-testid="stSidebar"][aria-expanded="true"]{
                      min-width: 200px;
                      max-width: 200px;
                }
                [data-testid="stSidebarNav"] {
                    background-position: -20px 20px;
                    text-align: center;
                    display: block;
                    background-image: url("data:image/png;base64,%s");
                    background-repeat: no-repeat;
                    margin-top: %s;
                    margin-left: auto;
                    margin-right: auto;
                    background-size: %s %s;
                    padding-top: 120px;
                }
                [data-testid="stSidebarNav"]::before {
                    text-align: center;
                    content: "InversAPP";
                    margin-left: -15px;
                    margin-top: 20px;
                    font-size: 30px;
                    position: relative;
                    top: 100px;
                }
            </style>
            """ % (
        binary_string,
        margin_top,
        image_width,
        image_height,
    )


def add_logo(png_file):
    logo_markup = build_markup_for_logo(png_file)
    st.markdown(
        logo_markup,
        unsafe_allow_html=True,
    )

add_logo("images/logon.png") 

if "identifier" not in st.session_state:
    st.session_state["identifier"] = None
st.write(st.session_state["identifier"])

property_translation = {
    "_id": "Identificador", "price": "Precio", "type": "Tipo", "title": "Título", "mobile": "Móvil",
    "address": "Zona", "city": "Ciudad", "age": "Antigüedad", "url": "Enlace", "rooms": "Habitaciones",
    "bathrooms": "Baños", "m2": "Metros cuadrados", "elevator": "Ascensor", "floor": "Piso", "balcony": "Balcón",
    "terrace": "Terraza", "heating": "Calefacción", "air_conditioning": "Aire acondicionado", "parking": "Parking",
    "pool": "Piscina", "id": "Identificacion", "transfer_taxes": "ITP","insurance": "Seguro", "ibi": "Inmueble", 
    "community": "Comunidad", "maintenance": "Mantenimiento", "costs": "Costos", "amount_to_pay": "Cantidad a pagar", 
    "total_mortgage": "Hipoteca total", "monthly_mortgage": "Hipoteca mensual", "incomes": "Ingresos", 
    "rentability": "Rentabilidad", "group": "Grupo inter-barrio", "percentile": "Percentil de barrio"
}

zone_translation = {
    "name": "Zona",
    "parent_zone": "Zona Principal",
    "Unnamed: 0": "Nombre completo",
    "rent": "Alquiler",
    "sell": "Venta",
    "subzones": "Subzonas",
    "rentability_sqm1rooms": "Rentabilidad m² 1 habitación",
    "rentability_sqm3rooms": "Rentabilidad m² 3 habitaciones",
    "rentability_sqm2rooms": "Rentabilidad m² 2 habitaciones",
    "rentability_sqm4rooms": "Rentabilidad m² 4 habitaciones",
    "rentability_terrace": "Rentabilidad Terraza",
    "rentability_elevator": "Rentabilidad Ascensor",
    "rentability_furnished": "Rentabilidad Amueblado",
    "rentability_parking": "Rentabilidad Parking",
    "avg_rentability": "Rentabilidad Media",
    "groups": "Tipos de vivienda por precio"
}

sell_rent_translation = {
    'sqm1rooms': 'Precio m² habitación Individual', 'sqm3rooms': 'Precio m² 3 habitaciones', 'sqm2rooms': 'Precio m² 2 habitaciones', 'sqm4rooms': 'Precio m² 4 habitaciones', 'terrace': 'Terraza',
    'elevator': 'Ascensor', 'furnished': 'Amueblado', 'parking': 'Parking', 'avgsqm': 'Promedio de m²', 'avgtype': 'Tipo promedio de casa', 'avgrooms': 'Promedio de habitaciones', 
    'avgfloors': 'Número Piso Promedio', 'pricepersqm': 'Precio promedio m²', 'price': 'Precio promedio viviendas', 'b100': 'Precio menos de 100 m²', 'a100': 'Precio más de 100 m²',
}

@st.cache_data
def get_property_data():
    df = pd.read_csv("properties_statistics.csv")
    df = df.rename(columns=property_translation)
    df.drop(columns=["Unnamed: 0", "Identificador"], inplace=True)
    df = df.apply(lambda col: pd.to_numeric(col, errors='ignore') if col.dtype == object else col)
    df = df.round(2)
    df = df[["Rentabilidad", "Precio", "Metros cuadrados", "Habitaciones", "Tipo", "Zona", "Ciudad", "Grupo inter-barrio", "Percentil de barrio", "Baños", "Antigüedad", "Piso", "Ascensor", "Balcón", "Terraza", "Calefacción", "Aire acondicionado", "Parking", "Piscina", "ITP", "Seguro", "Inmueble", "Comunidad", "Mantenimiento", "Costos", "Cantidad a pagar", "Hipoteca total", "Hipoteca mensual", "Ingresos", "Identificacion"]]
    # add a new metric called "Precio por m²" which is the price divided by the square meters
    df["Precio por m²"] = df["Precio"] / df["Metros cuadrados"]
    return df

@st.cache_data
def get_zone_data():
    df = pd.read_csv("zones_statistics.csv")
    df = df.rename(columns=zone_translation)
    df = df.apply(lambda col: pd.to_numeric(col, errors='ignore') if col.dtype == object else col)
    df = df.round(2)
    return df

@st.cache_data
def get_chart(dataframe, column):
    chart = alt.Chart(dataframe).mark_bar().encode(
        x=alt.X("Identificacion:N", title="Identificacion",
            sort=alt.EncodingSortField(field=column, order="ascending")),
        y=alt.Y(column + ":Q", title=column),
        color=alt.condition(
            alt.datum["Identificacion"] == property["Identificacion"],
            alt.value("red"),
            alt.value("blue")
        )
    ).properties(
        width=600,
        height=300
    )
    return chart

try:
    properties = get_property_data()
    zones = get_zone_data()
    property = properties[properties["Identificacion"] == st.session_state["identifier"]]
    if property.empty:
        st.error("No se ha encontrado la vivienda")
        st.stop()
    property = property.iloc[0]
    zone = zones[(zones["Zona"] == property["Zona"]) & (zones["Zona Principal"] == property["Ciudad"])].iloc[0]
    zone_properties = properties[(properties["Zona"] == property["Zona"]) & (properties["Ciudad"] == property["Ciudad"])]
    # remove the property from the zone properties
    #zone_properties = zone_properties[zone_properties["Identificacion"] != property["Identificacion"]]

    # Now we will display a list comparing the most important features of the property with the average of the zone
    # The most important features are Rentabilidad, Precio, Metros cuadrados, Habitaciones, Grupo inter-barrio, Percentil de barrio
    # Also a new featured called Precio por m² will be added
    st.write("Comparación de la vivienda con la media de la zona")
    # Now we want to display each comparison on a new component, if the component box is clicked a chart will be displayed
    # first we create the component boxes
    # we want the title to appear in the left of the box and the numeric comparison in the right, so we may have to use css
    # if the property is above the average, the color of the box will be green, if it is below, the color will be red

    rentability_box = st.expander("Rentabilidad de la vivienda: " + str(property["Rentabilidad"]) + "% vs " + str(zone_properties["Rentabilidad"].mean().round(2)) + "% Diferencia: " + str((property["Rentabilidad"] - zone_properties["Rentabilidad"].mean().round(2)).round(2)) + "%")
    price_box = st.expander("Precio de la vivienda: " + str(property["Precio"]) + "€ vs " + str(zone_properties["Precio"].mean().round(2)) + "€ Diferencia: " + str((property["Precio"] - zone_properties["Precio"].mean().round(2)).round(2)) + "€")
    sqm_box = st.expander("Metros cuadrados de la vivienda: " + str(property["Metros cuadrados"]) + "m² vs " + str(zone_properties["Metros cuadrados"].mean().round(2)) + "m² Diferencia: " + str((property["Metros cuadrados"] - zone_properties["Metros cuadrados"].mean().round(2)).round(2)) + "m²")
    price_per_sqm_box = st.expander("Precio por m² de la vivienda: " + str(property["Precio por m²"]) + "€/m² vs " + str(zone_properties["Precio por m²"].mean().round(2)) + "€/m² Diferencia: " + str((property["Precio por m²"] - zone_properties["Precio por m²"].mean().round(2)).round(2)) + "€/m²")
    rooms_box = st.expander("Habitaciones de la vivienda: " + str(property["Habitaciones"]) + " vs " + str(zone_properties["Habitaciones"].mean().round(2)) + " Diferencia: " + str((property["Habitaciones"] - zone_properties["Habitaciones"].mean().round(2)).round(2)))
    group_box = st.expander("Grupo inter-barrio")
    percentile_box = st.expander("Percentil de barrio: " + str(property["Percentil de barrio"]) + "% vs " + str(zone_properties["Percentil de barrio"].mean().round(2)) + "% Diferencia: " + str((property["Percentil de barrio"] - zone_properties["Percentil de barrio"].mean().round(2)).round(2)) + "%")
    

    # Now we will display a chart when the box is clicked, each property in zone_properties will be a separate bar in the chart, also they will also be displayed in blue
    # except for the property that is being compared, which will be displayed in red
    # as almost every chart will be the same, 
    rentability_chart = get_chart(zone_properties, "Rentabilidad")
    price_chart = get_chart(zone_properties, "Precio")
    sqm_chart = get_chart(zone_properties, "Metros cuadrados")
    price_per_sqm_chart = get_chart(zone_properties, "Precio por m²")
    rooms_chart = get_chart(zone_properties, "Habitaciones")
    percentile_box_chart = get_chart(zone_properties, "Percentil de barrio")


    # Now we will display the charts when the boxes are clicked
    rentability_box.write(rentability_chart)
    price_box.write(price_chart)
    sqm_box.write(sqm_chart)
    price_per_sqm_box.write(price_per_sqm_chart)
    rooms_box.write(rooms_chart)
    percentile_box.write(percentile_box_chart)
    group_box.write("El grupo inter-barrio es: " + str(property["Grupo inter-barrio"]))
        

except URLError as e:
    st.error(
        """
        This demo requires internet access.
        Connection error: %s
    """
        % e.reason
    )
