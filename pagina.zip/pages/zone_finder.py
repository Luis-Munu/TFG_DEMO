import streamlit as st

import pandas as pd
import altair as alt
from urllib.error import URLError
import base64
from streamlit_extras.switch_page_button import switch_page
from st_pages import Page, show_pages, hide_pages


st.set_page_config(page_title="Comparador de zonas", page_icon="🌍", layout="wide", initial_sidebar_state="collapsed")

st.markdown("""
        <style>
               .block-container {
                    padding-top: 1rem;
                    padding-bottom: 0rem;
                    padding-left: 5rem;
                    padding-right: 5rem;
                }
        </style>
        """, unsafe_allow_html=True)
st.markdown("<h1 style='text-align: center; color: grey;'>Comparador de zonas</h1>", unsafe_allow_html=True)
st.markdown("<h3 style='text-align: center; color: white;'><br><br>En esta pestaña se puede analizar el rendamiento de las zonas y compararlo con el de otras.</h1>", unsafe_allow_html=True)
show_pages(
    [
        Page("website.py", "Página principal", ":house:"),
        Page("pages/property_finder.py", "Buscador de viviendas", "🏠"),
        Page("pages/zone_finder.py", "Análisis por zonas", "🌍"),
        Page("pages/user_profile.py", "Menú de usuario", "✏️"),
        Page("pages/property_statistics.py","Caracteristicas de la propiedad", "📈"),
        Page("pages/zone_statistics.py","Estadisticas de la zona", "📊")
    ]
)

hide_pages(["Caracteristicas de la propiedad", "Estadisticas de la zona"])

st.markdown("""
  <style>
    .css-13sdm1b.e16nr0p33 {
      margin-top: -75px;
    }
  </style>
""", unsafe_allow_html=True)

st.markdown("""
        <style>
               .block-container {
                    padding-top: 1rem;
                    padding-bottom: 0rem;
                    padding-left: 5rem;
                    padding-right: 5rem;
                }
        </style>
        """, unsafe_allow_html=True)

def get_base64_of_bin_file(png_file):
    with open(png_file, "rb") as f:
        data = f.read()
    return base64.b64encode(data).decode()

def build_markup_for_logo(
    png_file,
    background_position="5% 5%",
    margin_top="10%",
    image_width="120%",
    image_height="",
):
    binary_string = get_base64_of_bin_file(png_file)
    return """
            <style>
                [data-testid="stSidebar"][aria-expanded="true"]{
                      min-width: 200px;
                      max-width: 200px;
                }
                [data-testid="stSidebarNav"] {
                    background-position: -20px 20px;
                    text-align: center;
                    display: block;
                    background-image: url("data:image/png;base64,%s");
                    background-repeat: no-repeat;
                    margin-top: %s;
                    margin-left: auto;
                    margin-right: auto;
                    background-size: %s %s;
                    padding-top: 120px;
                }
                [data-testid="stSidebarNav"]::before {
                    text-align: center;
                    content: "InversAPP";
                    margin-left: -15px;
                    margin-top: 20px;
                    font-size: 30px;
                    position: relative;
                    top: 100px;
                }
            </style>
            """ % (
        binary_string,
        margin_top,
        image_width,
        image_height,
    )


def add_logo(png_file):
    logo_markup = build_markup_for_logo(png_file)
    st.markdown(
        logo_markup,
        unsafe_allow_html=True,
    )

add_logo("images/logon.png")

general_translation = {
    "name": "Zona",
    "parent_zone": "Zona Principal",
    "Unnamed: 0": "Nombre completo",
    "rent": "Alquiler",
    "sell": "Venta",
    "subzones": "Subzonas",
    "rentability_sqm1rooms": "Rentabilidad m² 1 habitación",
    "rentability_sqm3rooms": "Rentabilidad m² 3 habitaciones",
    "rentability_sqm2rooms": "Rentabilidad m² 2 habitaciones",
    "rentability_sqm4rooms": "Rentabilidad m² 4 habitaciones",
    "rentability_terrace": "Rentabilidad Terraza",
    "rentability_elevator": "Rentabilidad Ascensor",
    "rentability_furnished": "Rentabilidad Amueblado",
    "rentability_parking": "Rentabilidad Parking",
    "avg_rentability": "Rentabilidad Media",
    "groups": "Tipos de vivienda por precio"
}

sell_rent_translation = {
    'sqm1rooms': 'Precio m² habitación Individual', 'sqm3rooms': 'Precio m² 3 habitaciones', 'sqm2rooms': 'Precio m² 2 habitaciones', 'sqm4rooms': 'Precio m² 4 habitaciones', 'terrace': 'Terraza',
    'elevator': 'Ascensor', 'furnished': 'Amueblado', 'parking': 'Parking', 'avgsqm': 'Promedio de m²', 'avgtype': 'Tipo promedio de casa', 'avgrooms': 'Promedio de habitaciones', 
    'avgfloors': 'Número Piso Promedio', 'pricepersqm': 'Precio promedio m²', 'price': 'Precio promedio viviendas', 'b100': 'Precio menos de 100 m²', 'a100': 'Precio más de 100 m²',
}


@st.cache_data
def get_zone_data():
    df = pd.read_csv("zones_statistics.csv")
    df = df.rename(columns=general_translation)
    df = df.apply(lambda col: pd.to_numeric(col, errors='ignore') if col.dtype == object else col)
    return df.set_index("Zona")


try:
    df = get_zone_data()
    df = df.sort_values(by="Zona", ascending=False)
    drop1, drop2 = st.columns([2,2])

    display_option = drop1.selectbox(
        "Elige una opción de visualización", options=['General', 'Alquiler', 'Venta']
    )

    if display_option != 'General':
        df = df.reset_index()
        df2 = df[display_option].apply(lambda x: eval(x))
        df2 = pd.json_normalize(df2)
        df2 = df2.rename(columns=sell_rent_translation)
        df = pd.concat([df[['Zona', 'Zona Principal', 'Nombre completo', 'Rentabilidad Media']], df2], axis=1)
        df.set_index("Zona", inplace=True)
    else:
        df = df.drop(columns=['Alquiler', 'Venta', 'Subzonas'])

    zones = st.multiselect(
        "Busca una zona en concreto", list(df.index)
    )

    columns = list(df.select_dtypes(include='number').columns)

    sort_column = drop2.selectbox("Selecciona una estadística a comparar", options=columns, index=0)

    data = df.loc[zones] if zones else df

    data = data.sort_values(by=sort_column, ascending=False)

    st.write("### Todos los datos", data)

    data = data.reset_index().melt(id_vars=["Zona"], value_vars=[sort_column])
    st.write("### Comparación en gráfico")
    chart = (
        alt.Chart(data.head(10))
        .mark_bar()
        .encode(
            x=alt.X("Zona:N", sort='-y'),
            y=alt.Y("value:Q", title=sort_column),
            color="Zona:N",
        )
    )
    st.altair_chart(chart, use_container_width=True)





except URLError as e:
    st.error(
        """
        This demo requires internet access.
        Connection error: %s
    """
        % e.reason
    )