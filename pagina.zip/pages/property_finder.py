import streamlit as st
import pandas as pd
from urllib.error import URLError
from st_aggrid import AgGrid, GridOptionsBuilder, ColumnsAutoSizeMode
from st_aggrid.shared import GridUpdateMode
from streamlit_extras.switch_page_button import switch_page
from st_pages import Page, show_pages, hide_pages
import base64

st.set_page_config(page_title="Buscador de viviendas", page_icon="🏠", layout="wide", initial_sidebar_state="collapsed")

st.markdown("""
        <style>
               .block-container {
                    padding-top: 1rem;
                    padding-bottom: 0rem;
                    padding-left: 10rem;
                    padding-right: 10rem;
                }
        </style>
        """, unsafe_allow_html=True)
st.markdown("<h1 style='text-align: center; color: grey;'>Buscador de viviendas</h1>", unsafe_allow_html=True)
st.markdown("<h3 style='text-align: center; color: white;'><br><br>Busca rápidamente las viviendas más rentables.</h1>", unsafe_allow_html=True)

st.markdown("")
show_pages(
    [
        Page("website.py", "Página principal", ":house:"),
        Page("pages/property_finder.py", "Buscador de viviendas", "🏠"),
        Page("pages/zone_finder.py", "Análisis por zonas", "🌍"),
        Page("pages/user_profile.py", "Menú de usuario", "✏️"),
        Page("pages/property_statistics.py","Caracteristicas de la propiedad", "📈"),
        Page("pages/zone_statistics.py","Estadisticas de la zona", "📊")
    ]
)

hide_pages(["Caracteristicas de la propiedad", "Estadisticas de la zona"])

st.markdown("""
  <style>
    .css-13sdm1b.e16nr0p33 {
      margin-top: -75px;
    }
  </style>
""", unsafe_allow_html=True)

st.markdown("""
        <style>
               .block-container {
                    padding-top: 1rem;
                    padding-bottom: 0rem;
                    padding-left: 5rem;
                    padding-right: 5rem;
                }
        </style>
        """, unsafe_allow_html=True)

def get_base64_of_bin_file(png_file):
    with open(png_file, "rb") as f:
        data = f.read()
    return base64.b64encode(data).decode()

def build_markup_for_logo(
    png_file,
    background_position="5% 5%",
    margin_top="10%",
    image_width="120%",
    image_height="",
):
    binary_string = get_base64_of_bin_file(png_file)
    return """
            <style>
                [data-testid="stSidebar"][aria-expanded="true"]{
                      min-width: 200px;
                      max-width: 200px;
                }
                [data-testid="stSidebarNav"] {
                    background-position: -20px 20px;
                    text-align: center;
                    display: block;
                    background-image: url("data:image/png;base64,%s");
                    background-repeat: no-repeat;
                    margin-top: %s;
                    margin-left: auto;
                    margin-right: auto;
                    background-size: %s %s;
                    padding-top: 120px;
                }
                [data-testid="stSidebarNav"]::before {
                    text-align: center;
                    content: "InversAPP";
                    margin-left: -15px;
                    margin-top: 20px;
                    font-size: 30px;
                    position: relative;
                    top: 100px;
                }
            </style>
            """ % (
        binary_string,
        margin_top,
        image_width,
        image_height,
    )


def add_logo(png_file):
    logo_markup = build_markup_for_logo(png_file)
    st.markdown(
        logo_markup,
        unsafe_allow_html=True,
    )

add_logo("images/logon.png")

general_translation = {
    "_id": "Identificador", "price": "Precio", "type": "Tipo", "title": "Título", "mobile": "Móvil",
    "address": "Zona", "city": "Ciudad", "age": "Antigüedad", "url": "Enlace", "rooms": "Habitaciones",
    "bathrooms": "Baños", "m2": "Metros cuadrados", "elevator": "Ascensor", "floor": "Piso", "balcony": "Balcón",
    "terrace": "Terraza", "heating": "Calefacción", "air_conditioning": "Aire acondicionado", "parking": "Parking",
    "pool": "Piscina", "id": "Identificacion", "transfer_taxes": "ITP","insurance": "Seguro", "ibi": "Inmueble", 
    "community": "Comunidad", "maintenance": "Mantenimiento", "costs": "Costos", "amount_to_pay": "Cantidad a pagar", 
    "total_mortgage": "Hipoteca total", "monthly_mortgage": "Hipoteca mensual", "incomes": "Ingresos", 
    "rentability": "Rentabilidad", "group": "Grupo inter-barrio", "percentile": "Percentil de barrio"
}

if "show_filters" not in st.session_state:
    st.session_state["show_filters"] = False
if "show_navigation" not in st.session_state:
    st.session_state["show_navigation"] = False
if "identifier" not in st.session_state:
    st.session_state["identifier"] = None

@st.cache_data
def get_property_data():
    df = pd.read_csv("properties_statistics.csv")
    df = df.rename(columns=general_translation)
    df.drop(columns=["Unnamed: 0", "Identificador"], inplace=True)
    df = df.apply(lambda col: pd.to_numeric(col, errors='ignore') if col.dtype == object else col)
    df = df.round(2)
    df = df[["Rentabilidad", "Precio", "Metros cuadrados", "Habitaciones", "Tipo", "Zona", "Ciudad", "Grupo inter-barrio", "Percentil de barrio", "Baños", "Antigüedad", "Piso", "Ascensor", "Balcón", "Terraza", "Calefacción", "Aire acondicionado", "Parking", "Piscina", "ITP", "Seguro", "Inmueble", "Comunidad", "Mantenimiento", "Costos", "Cantidad a pagar", "Hipoteca total", "Hipoteca mensual", "Ingresos", "Identificacion"]]
    return df

try:
    df = get_property_data()
    df = df.sort_values(by="Rentabilidad", ascending=False)
    datacol, filtercol = st.columns((10, 3))

    with filtercol:
        if st.session_state["show_navigation"]:
            if st.button("Ir a vivienda"):
                st.session_state["show_navigation"] = False
                switch_page("Caracteristicas de la propiedad")
        if st.button("Filtrar"):
            st.session_state["show_filters"] = not st.session_state["show_filters"]

        if st.session_state["show_filters"]:
            zone = st.multiselect("Zona", options=df['Zona'].unique())
            city = st.multiselect("Ciudad", options=df['Ciudad'].unique())
            property_type = st.multiselect("Tipo", options=df['Tipo'].unique())
            rooms = st.slider("Habitaciones", int(df['Habitaciones'].min()), int(df['Habitaciones'].max()), value=int(df['Habitaciones'].min()))
            bathrooms = st.slider("Baños", int(df['Baños'].min()), int(df['Baños'].max()), value=int(df['Baños'].min()))

            if property_type:
                df = df[df['Tipo'].isin(property_type)]
            if zone:
                df = df[df['Zona'].isin(zone)]
            if city:
                df = df[df['Ciudad'].isin(city)]
            df = df[(df['Habitaciones'] >= rooms) & (df['Baños'] >= bathrooms)]

    with datacol:
        options = GridOptionsBuilder.from_dataframe(
        df, enableRowGroup=True, enableValue=True, enablePivot=True
        )
        options.configure_selection("single")
        selection = AgGrid(df, height=3000, enable_enterprise_module = True, 
                           gridOptions = options.build(), update_mode=GridUpdateMode.MODEL_CHANGED, 
                           columns_auto_size_mode=ColumnsAutoSizeMode.FIT_CONTENTS,
                           reload_data= True, width=1000, allow_unsafe_jscode=True)
        if selection and len(selection["selected_rows"]) > 0:
            st.session_state["show_navigation"] = True
            st.session_state["identifier"] = selection["selected_rows"][0]["Identificacion"]
            
        

except URLError as e:
    st.error(
        """
        This demo requires internet access.
        Connection error: %s
    """
        % e.reason
    )