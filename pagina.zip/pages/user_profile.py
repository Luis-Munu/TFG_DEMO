import streamlit as st
from PIL import Image
import base64
from streamlit_extras.switch_page_button import switch_page
from st_pages import Page, show_pages, hide_pages
st.set_page_config(page_title="Perfil de usuario", page_icon="🌍", layout="wide", initial_sidebar_state="collapsed")

st.markdown("""
        <style>
               .block-container {
                    padding-top: 1rem;
                    padding-bottom: 0rem;
                    padding-left: 5rem;
                    padding-right: 5rem;
                }
        </style>
        """, unsafe_allow_html=True)

st.markdown("<h1 style='text-align: center; color: grey;'>Perfil de usuario</h1>", unsafe_allow_html=True)
st.markdown("<h3 style='text-align: center; color: white;'><br><br>En esta página podrás gestionar tus datos, preferencias y propiedades favoritas.</h1>", unsafe_allow_html=True)
show_pages(
    [
        Page("website.py", "Página principal", ":house:"),
        Page("pages/property_finder.py", "Buscador de viviendas", "🏠"),
        Page("pages/zone_finder.py", "Análisis por zonas", "🌍"),
        Page("pages/user_profile.py", "Menú de usuario", "✏️"),
        Page("pages/property_statistics.py","Caracteristicas de la propiedad", "📈"),
        Page("pages/zone_statistics.py","Estadisticas de la zona", "📊")
    ]
)

hide_pages(["Caracteristicas de la propiedad", "Estadisticas de la zona"])

st.markdown("""
  <style>
    .css-13sdm1b.e16nr0p33 {
      margin-top: -75px;
    }
  </style>
""", unsafe_allow_html=True)

st.markdown("""
        <style>
               .block-container {
                    padding-top: 1rem;
                    padding-bottom: 0rem;
                    padding-left: 5rem;
                    padding-right: 5rem;
                }
        </style>
        """, unsafe_allow_html=True)

def get_base64_of_bin_file(png_file):
    with open(png_file, "rb") as f:
        data = f.read()
    return base64.b64encode(data).decode()

def build_markup_for_logo(
    png_file,
    background_position="5% 5%",
    margin_top="10%",
    image_width="120%",
    image_height="",
):
    binary_string = get_base64_of_bin_file(png_file)
    return """
            <style>
                [data-testid="stSidebar"][aria-expanded="true"]{
                      min-width: 200px;
                      max-width: 200px;
                }
                [data-testid="stSidebarNav"] {
                    background-position: -20px 20px;
                    text-align: center;
                    display: block;
                    background-image: url("data:image/png;base64,%s");
                    background-repeat: no-repeat;
                    margin-top: %s;
                    margin-left: auto;
                    margin-right: auto;
                    background-size: %s %s;
                    padding-top: 120px;
                }
                [data-testid="stSidebarNav"]::before {
                    text-align: center;
                    content: "InversAPP";
                    margin-left: -15px;
                    margin-top: 20px;
                    font-size: 30px;
                    position: relative;
                    top: 100px;
                }
            </style>
            """ % (
        binary_string,
        margin_top,
        image_width,
        image_height,
    )


def add_logo(png_file):
    logo_markup = build_markup_for_logo(png_file)
    st.markdown(
        logo_markup,
        unsafe_allow_html=True,
    )

add_logo("images/logon.png")


# push the content down multiple lines
st.markdown("<br><br> </br>", unsafe_allow_html=True)

column1, column2 = st.columns([1, 2])

with column2:
        field1, field2 = st.columns(2)
        if "user_name" not in st.session_state: st.session_state["user_name"] = "Pepito Perez"
        user_name = field1.text_input(label="Nombre de usuario", value=st.session_state["user_name"], key="user_name_input")
        st.session_state["user_name"] = user_name


        if "email" not in st.session_state: st.session_state["email"] = "pepitus@gmail.com"
        email = field2.text_input(label="Correo electrónico", value=st.session_state["email"], key="email_input")
        st.session_state["email"] = email

        field3, field4 = st.columns(2)
        if "age" not in st.session_state: st.session_state["age"] = "35"
        age = field3.text_input(label="Edad", value=st.session_state["age"], key="age_input")
        st.session_state["age"] = age

        if "salary" not in st.session_state: st.session_state["salary"] = "1780"
        salary = field4.text_input(label="Salario mensual", value=st.session_state["salary"], key="salary_input")
        st.session_state["salary"] = salary

        field5, field6 = st.columns(2)
        if "cash" not in st.session_state: st.session_state["cash"] = "35000"
        cash = field5.text_input(label="Cantidad en Efectivo", value=st.session_state["cash"], key="cash_input")
        st.session_state["cash"] = cash

        if "max_amount" not in st.session_state: st.session_state["max_amount"] = "120000"
        max_amount = field6.text_input(label="Límite de inversión", value=st.session_state["max_amount"], key="max_amount_input")
        st.session_state["max_amount"] = max_amount

        banks = {
                "Santander": {
                        "name": "Santander",
                        "interest_rate": 0.0523,
                        "max_mortgage_age": 80
                }, 
                "Caixabank": {
                        "name": "Caixabank",
                        "interest_rate": 0.0516,
                        "max_mortgage_age": 75
                },
                "Sabadell": {
                        "name": "Sabadell",
                        "interest_rate": 0.0496,
                        "max_mortgage_age": 75
                },
                "Unicaja": {
                        "name": "Unicaja",
                        "interest_rate": 0.0444,
                        "max_mortgage_age": 70
                },
                "Bankinter": {
                        "name": "Bankinter",
                        "interest_rate": 0.0508,
                        "max_mortgage_age": 75
                },
                "Abanca": {
                        "name": "Abanca",
                        "interest_rate": 0.0574,
                        "max_mortgage_age": 75
                },
                "Ibercaja": {
                        "name": "Ibercaja",
                        "interest_rate": 0.0452,
                        "max_mortgage_age": 75
                },
                "BBVA": {
                        "name": "BBVA",
                        "interest_rate": 0.0447,
                        "max_mortgage_age": 70
                }
        }
        if "bank" not in st.session_state: st.session_state["bank"] = ""
        bank = st.selectbox(label="Banco", options=banks, index=0, key="bank_select")
        st.session_state["bank"] = banks[bank]

        # show the selected bank's interest rate and max mortgage age
        st.markdown(f"**Tasa de interés:** {st.session_state['bank']['interest_rate']}")
        st.markdown(f"**Edad máxima de la hipoteca:** {st.session_state['bank']['max_mortgage_age']}")

with column1:
        image = Image.open('images/logon.png')
        st.image(image, width=500)
